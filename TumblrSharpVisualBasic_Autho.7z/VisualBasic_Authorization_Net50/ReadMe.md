﻿# prerequisite

[Microsoft Edge WebView2  Runtime x64](https://developer.microsoft.com/en-us/microsoft-edge/webview2/#download-section)